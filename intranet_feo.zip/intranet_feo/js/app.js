document.addEventListener("DOMContentLoaded", () => {
    checkSession();
});

//-----------------------------------------
function checkSession() {
    fetch("php/auth/checkSession.php")
        .then(r => r.json())
        .then(d => {
            if (d.logged) {
                window.location.href = "orrinagusia.html";
            } else {
                loadLoginForm();
            }
        })
        .catch(() => loadLoginForm());
}

//-----------------------------------------
function loadLoginForm() {

    const html = `
    <div class="login-container">
        <h2>Login</h2>

        <input type="text" id="inUsername" placeholder="Erabiltzailea">
        <input type="password" id="inPassword" placeholder="Pasahitza">

        <button id="btnLogin">Sartu</button>
        <button id="btnShowRegister">Erregistratu</button>
    </div>`;

    document.getElementById("divMain").innerHTML = html;

    document.getElementById("btnLogin").onclick = login;
    document.getElementById("btnShowRegister").onclick = loadRegisterForm;
}

//-----------------------------------------
function loadRegisterForm() {

    const html = `
    <div class="login-container">
        <h2>Erregistroa</h2>

        <input type="text" id="reName" placeholder="Izena">
        <input type="text" id="reSurname" placeholder="Abizena">
        <input type="text" id="reUsername" placeholder="Erabiltzailea">
        <input type="password" id="rePassword" placeholder="Pasahitza">

        <button id="btnRegister">Sortu erabiltzailea</button>
        <button id="btnBack">Atzera</button>
    </div>`;

    document.getElementById("divMain").innerHTML = html;

    document.getElementById("btnRegister").onclick = register;
    document.getElementById("btnBack").onclick = loadLoginForm;
}

//-----------------------------------------
function login() {

    const data = new URLSearchParams({
        username: document.getElementById("inUsername").value,
        password: document.getElementById("inPassword").value
    });

    fetch("php/login/adlogin.php", {
        method: "POST",
        body: data
    })
        .then(r => r.json())
        .then(d => {
            if (d.success) {
                window.location.href = "orrinagusia.html";
            } else {
                alert("Login okerra");
            }
        });
}

//-----------------------------------------
function register() {

    const data = new URLSearchParams({
        name: document.getElementById("reName").value,
        surname: document.getElementById("reSurname").value,
        username: document.getElementById("reUsername").value,
        password: document.getElementById("rePassword").value
    });

    fetch("php/auth/register.php", {
        method: "POST",
        body: data
    })
        .then(r => r.json())
        .then(d => {
            if (d.success) {
                alert("Erabiltzailea sortuta");
                loadLoginForm();
            } else {
                alert(d.msg || "Errorea");
            }
        });
}
