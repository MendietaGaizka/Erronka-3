<?php
ini_set('display_errors', 0);
error_reporting(0);

header('Content-Type: application/json; charset=utf-8');
session_start();

$config = require __DIR__ . '/../config/ldap.php';

$username = trim($_POST['username'] ?? '');
$password = trim($_POST['password'] ?? '');

if ($username === '' || $password === '') {
    echo json_encode(['success' => false, 'msg' => 'Datuak falta dira']);
    exit;
}

// Conexión LDAP
$ldap = ldap_connect($config['host'], $config['port']);
if (!$ldap) {
    echo json_encode(['success' => false, 'msg' => 'LDAP connect error']);
    exit;
}

ldap_set_option($ldap, LDAP_OPT_PROTOCOL_VERSION, 3);
ldap_set_option($ldap, LDAP_OPT_REFERRALS, 0);

// Login contra AD
$userDn = $config['domain'] . '\\' . $username;

if (@ldap_bind($ldap, $userDn, $password)) {

    // LOGIN OK
    $_SESSION['user'] = $username;
    $_SESSION['login_time'] = time();

    echo json_encode(['success' => true]);

} else {

    echo json_encode(['success' => false, 'msg' => 'Login okerra']);
}

ldap_unbind($ldap);
