<?php
return [
    // DC / AD
    'host' => '192.168.0.1',
    'port' => 389,

    // Dominio
    'domain' => 'PUNKETS',

    // Base DN
    'base_dn' => 'DC=punkets,DC=lan',

    // OU donde se crean los nuevos usuarios
    'users_ou' => 'OU=newuser,OU=banco_punkets',

    // Usuario técnico del AD (para register)
    'admin_user' => 'PUNKETS\\ander',
    'admin_pass' => 'Admin123'   // usa una contraseña válida según policy
];
