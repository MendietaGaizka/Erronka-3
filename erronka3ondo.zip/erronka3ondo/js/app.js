document.addEventListener("DOMContentLoaded", () => {
    checkSession();
});

function checkSession() {
    fetch("php/auth/checkSession.php")
        .then(response => response.json())
        .then(data => {

            // No logueado
            if (!data.logged) {
                if (!location.pathname.endsWith("index.html")) {
                    location.href = "index.html";
                } else {
                    loadLogin();
                }
                return;
            }

            // Logueado → redirigir por rol
            if (data.role === "admin") {
                if (!location.pathname.endsWith("home.html")) {
                    location.href = "home.html";
                }
            } else {
                if (!location.pathname.endsWith("orrinagusia_user.html")) {
                    location.href = "orrinagusia_user.html";
                }
            }

            // Mostrar usuario si existe
            if (typeof user !== "undefined") {
                user.innerText = data.user;
            }

            // Botón logout si existe
            if (typeof btnLogout !== "undefined") {
                btnLogout.onclick = logout;
            }
        });
}

function loadLogin() {
    app.innerHTML = `
        <div class="card">
            <h2>Login</h2>

            <input id="lUser" placeholder="Erabiltzailea">
            <input id="lPass" type="password" placeholder="Pasahitza">

            <button onclick="login()">Hasi saioa</button>

            <div id="msg"></div>
        </div>
    `;
}

function login() {
    fetch("php/auth/login.php", {
        method: "POST",
        body: new URLSearchParams({
            username: lUser.value,
            password: lPass.value
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            checkSession();
        } else {
            msg.innerHTML = `<div class="error">Errorea AD</div>`;
        }
    });
}

function logout() {
    fetch("php/auth/logout.php")
        .then(() => location.href = "index.html");
}
