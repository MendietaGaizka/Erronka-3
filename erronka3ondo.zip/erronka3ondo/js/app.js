document.addEventListener("DOMContentLoaded", () => {
    checkSession();
});

function checkSession() {
    fetch("php/auth/checkSession.php")
        .then(response => response.json())
        .then(data => {
            if (data.logged) {
                if (!location.pathname.endsWith("home.html")) {
                    location.href = "home.html";
                } else {
                    user.innerText = data.user;
                    btnLogout.onclick = logout;
                }
            } else {
                if (!location.pathname.endsWith("index.html")) {
                    location.href = "index.html";
                } else {
                    loadLogin();
                }
            }
        });
}

function loadLogin() {
    app.innerHTML = `
        <div class="card">
            <h2>Login</h2>

            <input id="lUser" placeholder="Erabiltzailea">
            <input id="lPass" type="password" placeholder="Pasahitza">

            <button onclick="login()">Hasi saioa</button>
            <button class="secondary" onclick="loadRegister()">Erregistratu</button>

            <div id="msg"></div>
        </div>
    `;
}

function loadRegister() {
    app.innerHTML = `
        <div class="card">
            <h2>Erregistroa</h2>

            <input id="rName" placeholder="Izena">
            <input id="rSurname" placeholder="Abizena">
            <input id="rUser" placeholder="Erabiltzailea">
            <input id="rPass" type="password" placeholder="Pasahitza">

            <button onclick="register()">Sortu erabiltzailea</button>
            <button class="secondary" onclick="loadLogin()">Atzera</button>

            <div id="msg"></div>
        </div>
    `;
}

function login() {
    fetch("php/auth/login.php", {
        method: "POST",
        body: new URLSearchParams({
            username: lUser.value,
            password: lPass.value
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            checkSession();
        } else {
            msg.innerHTML = '<div class="error">Errorea AD</div>';
        }
    });
}

function register() {
    fetch("php/auth/register.php", {
        method: "POST",
        body: new URLSearchParams({
            name: rName.value,
            surname: rSurname.value,
            username: rUser.value,
            password: rPass.value
        })
    })
    .then(response => response.json())
    .then(data => {
        msg.innerHTML = data.success
            ? '<div class="success">Sortuta</div>'
            : '<div class="error">Errorea DB</div>';
    });
}

function logout() {
    fetch("php/auth/logout.php")
        .then(() => location.href = "index.html");
}
