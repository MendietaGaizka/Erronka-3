<?php
include "../config.php";
$c=new mysqli($db_host,$db_user,$db_pass,$db_name);
$h=password_hash($_POST['password'],PASSWORD_DEFAULT);
$s=$c->prepare("INSERT INTO users(name,surname,username,password) VALUES(?,?,?,?)");
$s->bind_param("ssss",$_POST['name'],$_POST['surname'],$_POST['username'],$h);
echo json_encode(["success"=>$s->execute()]);
