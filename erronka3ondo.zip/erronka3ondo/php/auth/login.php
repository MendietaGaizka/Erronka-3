<?php
session_start();
include "../config.php";

header("Content-Type: application/json");

$user = $_POST['username'] ?? '';
$pass = $_POST['password'] ?? '';

if ($user === '' || $pass === '') {
    echo json_encode([
        "success" => false,
        "error" => "Campos vacíos"
    ]);
    exit;
}

/*
================================================
 CONFIG AD CORRECTA (UPN)
================================================
 En config.php debe estar:
 $ad_domain = "punkets.lan";
 $ad_server = "ldap://IP_REAL_DEL_DC";
*/

// Conectar LDAP
$ldap = @ldap_connect($ad_server);
if (!$ldap) {
    echo json_encode([
        "success" => false,
        "error" => "No se puede conectar al servidor LDAP"
    ]);
    exit;
}

// Opciones LDAP
ldap_set_option($ldap, LDAP_OPT_PROTOCOL_VERSION, 3);
ldap_set_option($ldap, LDAP_OPT_REFERRALS, 0);

// Bind usando UPN (FORMA CORRECTA)
$bindUser = "$user@$ad_domain";

if (!@ldap_bind($ldap, $bindUser, $pass)) {
    echo json_encode([
        "success" => false,
        "error" => "Fallo bind AD: " . ldap_error($ldap)
    ]);
    exit;
}

// Buscar usuario dentro de la OU padre
$filter = "(sAMAccountName=$user)";
$search = @ldap_search($ldap, $ad_base_dn, $filter);

if (!$search) {
    echo json_encode([
        "success" => false,
        "error" => "Error en búsqueda LDAP"
    ]);
    exit;
}

$entries = ldap_get_entries($ldap, $search);

if ($entries["count"] === 0) {
    echo json_encode([
        "success" => false,
        "error" => "Usuario no pertenece a la OU permitida"
    ]);
    exit;
}

// ✅ LOGIN CORRECTO
$_SESSION["user"] = $user;

echo json_encode([
    "success" => true
]);
