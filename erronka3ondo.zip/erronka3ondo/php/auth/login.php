<?php
session_start();
include "../config.php";

header("Content-Type: application/json");

$user = $_POST['username'] ?? '';
$pass = $_POST['password'] ?? '';

if ($user === '' || $pass === '') {
    echo json_encode(["success" => false]);
    exit;
}

/* ===== CONEXIÓN A AD ===== */
$ldap = ldap_connect($ad_server);
if (!$ldap) {
    echo json_encode(["success" => false]);
    exit;
}

ldap_set_option($ldap, LDAP_OPT_PROTOCOL_VERSION, 3);
ldap_set_option($ldap, LDAP_OPT_REFERRALS, 0);

/* ===== BIND ===== */
if (!@ldap_bind($ldap, "$user@$ad_domain", $pass)) {
    echo json_encode(["success" => false]);
    exit;
}

/* ===== BUSCAR USUARIO ===== */
$filter = "(sAMAccountName=$user)";
$search = ldap_search($ldap, $ad_base_dn, $filter);
$entries = ldap_get_entries($ldap, $search);

if ($entries["count"] === 0) {
    echo json_encode(["success" => false]);
    exit;
}

/* ===== DETERMINAR ROL ===== */
$role = "user";

if (isset($entries[0]["memberof"])) {
    foreach ($entries[0]["memberof"] as $group) {
        if (
            is_string($group) &&
            stripos($group, "CN=punkets-admin") !== false
        ) {
            $role = "admin";
            break;
        }
    }
}

/* ===== GUARDAR SESIÓN (CLAVE) ===== */
$_SESSION["user"] = $user;
$_SESSION["role"] = $role;

/* ===== RESPUESTA ===== */
echo json_encode([
    "success" => true,
    "role" => $role
]);
