<?php
$db_host="localhost";
$db_user="root";
$db_pass="Admin123";
$db_name="2erronkabn";
$ad_server="ldap://192.168.0.1";
$ad_domain="punkets.lan";
$ad_base_dn="OU=banco_punkets,DC=punkets,DC=lan";
